Set-Location "c:\Users\dhall\New folder"

$zipName = "voyager-game.zip"
if (Test-Path $zipName) {
    Remove-Item $zipName -Force
}

$entries = @(
    "index.html",
    "README.md",
    "firebase.json",
    ".gitignore",
    "css",
    "js",
    "assets"
)

Compress-Archive -Path $entries -DestinationPath $zipName -Force

$artDir = "C:\Users\dhall\.gemini\antigravity-ide\brain\3fd20699-c20f-4e44-ba02-12e26b723fb2"
Copy-Item $zipName -Destination (Join-Path $artDir $zipName) -Force

$downloadsDir = "C:\Users\dhall\Downloads"
if (Test-Path $downloadsDir) {
    Copy-Item $zipName -Destination (Join-Path $downloadsDir $zipName) -Force
}

Get-Item $zipName | Select-Object FullName, Length
